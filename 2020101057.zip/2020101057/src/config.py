rows, columns = 30, 90
frames = 15
global_time = 0
limit_y = columns - 1
limit_x = rows - 1
# global_time = 0
# end_time = 